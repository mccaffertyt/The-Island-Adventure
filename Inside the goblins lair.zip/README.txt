This zip was generated via the Adventure Bundler (v0.2.2) module for Foundry.
Please install and activate the module in order to import this adventure.

https://github.com/dmarcuse/fvtt-adventure-bundler
